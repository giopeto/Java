package com.springbootmicrometerprometheusgrafana;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootMicrometerPrometheusGrafanaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootMicrometerPrometheusGrafanaApplication.class, args);
	}

}
